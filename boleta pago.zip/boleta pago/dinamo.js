let nombre_empresa = prompt("Nombre de la empresa")
let direction = prompt("Ingrese la direccion")
let ruc = prompt("Ingrese el ruc de la empresa")
let telefono = prompt("Ingrese el telefono de la empresa")
let cliente = prompt("Nombre del cliente")
let dni = prompt("Ingrese el dni del cliente")
let fecha = prompt("Ingrese fecha")
let hora = prompt("Ingrese hora")
let medio_pago = prompt("Medio de pago")
let cant = prompt("Ingrese cantidad de productos")
let totalidad_pago = prompt("Ingrese el total")

let productos = [];
for(i=1;i<=cant;i++){
    let nombre_producto = prompt("Ingrese producto")
    productos.push(nombre_producto)
}

let empresa = document.getElementById("empresa")
let direccion = document.getElementById("direccion")
let ruc_empresa = document.getElementById("ruc")
let telephone = document.getElementById("telefono")
let consumidor = document.getElementById("cliente")
let DNI = document.getElementById("dni");
let fech = document.getElementById("Fecha")
let hour = document.getElementById("hora")
//total
let total = document.getElementById("total")
//producto
let producto = document.getElementById("producto")
let medio = document.getElementById("medio")

function cambiar(){
    empresa.innerHTML=nombre_empresa
    direccion.innerHTML="Dirección: "+direction
    ruc_empresa.innerHTML="RUC: "+ruc
    telephone.innerHTML="Telefono: "+telefono
    consumidor.innerHTML="Cliente: "+cliente
    DNI.innerHTML="DNI: "+dni
    fech.innerHTML="Fecha:  "+fecha
    hour.innerHTML="Hora:  "+hora 
    producto.innerHTML= productos.toString()
    medio.innerHTML=medio_pago
    total.innerHTML="Total: S/."+totalidad_pago
    boton.style.display="none"
}

let boton = document.getElementById("boleta")
boton.addEventListener('click',cambiar)